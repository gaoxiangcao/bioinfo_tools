class ParsingError(Exception):
    pass

class RemoveTempError(Exception):
    pass