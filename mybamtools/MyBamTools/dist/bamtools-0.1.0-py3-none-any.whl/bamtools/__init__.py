from bamtools._error import ParsingError, RemoveTempError
from bamtools._logging import set_logging_level